package com.issach;

public class Student
{
	public  Student()
	{
		System.out.println("hello...!");
	}
	

}
