package com.propertyDI;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass10
{
	public static void main(String[] args) 
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("property.xml");
		
		Test test1 = (Test)context.getBean("t");
		
		System.out.println(test1);
		
		
	}

}
