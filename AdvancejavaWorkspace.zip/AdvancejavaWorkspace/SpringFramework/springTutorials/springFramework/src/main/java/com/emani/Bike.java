package com.emani;

public class Bike
{
	
	public  Bike()
	{
		System.out.println("Bike racing statred....!");
	}
}
