package com.CollectionDI;

import java.util.*;

public class Info
{
	private List carNames;
	
	private Set bikeNames;
	
	private Map mobileModel;
	
	
	public void setCarNames(List carNames) {
		this.carNames = carNames;
	}

	
	public void setBikeNames(Set bikeNames) {
		this.bikeNames = bikeNames;
	}

	
	public void setMobileModel(Map mobileModel) {
		this.mobileModel = mobileModel;
	}


	@Override
	public String toString() {
		return "Info [carNames=" + carNames + ", bikeNames=" + bikeNames + ", mobileModel=" + mobileModel + "]";
	}
}
