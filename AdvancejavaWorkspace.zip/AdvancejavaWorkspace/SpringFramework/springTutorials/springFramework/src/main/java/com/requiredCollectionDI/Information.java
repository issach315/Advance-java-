package com.requiredCollectionDI;

import java.util.*;

public class Information
{
	private Vector cars;
	
	private TreeSet wine;
	
	private Hashtable counteryCapital;

	public Vector getCars() {
		return cars;
	}

	public void setCars(Vector cars) {
		this.cars = cars;
	}

	public TreeSet getWine() {
		return wine;
	}

	public void setWine(TreeSet wine) {
		this.wine = wine;
	}

	public Hashtable getCounteryCapital() {
		return counteryCapital;
	}

	public void setCounteryCapital(Hashtable counteryCapital) {
		this.counteryCapital = counteryCapital;
	}

	@Override
	public String toString() {
		return "Information [cars=" + cars + ", wine=" + wine + ", counteryCapital=" + counteryCapital + "]";
	}

	
	
	
	
	

}
