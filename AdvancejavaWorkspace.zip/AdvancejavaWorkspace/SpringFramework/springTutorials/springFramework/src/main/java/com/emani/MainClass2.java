package com.emani;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass2
{
	public static void main(String[] args) 
	{	
		//finding the xml file and loading IOC container 
		ApplicationContext context = new ClassPathXmlApplicationContext("sample1.xml");
		// creating Bike class object
		context.getBean("bike");
		
	}

}
