package com.propertyDI;

import java.util.Properties;
import java.util.Set;

public class Test 
{
	private Properties driver;
	
	public void setDriver(Properties driver)
	{
		this.driver=driver;
	}

	@Override
	public String toString() {
		return "Test [driver=" + driver + "]";
	}
	
	
	
	
}
