package com.CollectionDI;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass06 
{
	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("CollectionDI.xml");
		
		Info info1 = (Info)context.getBean("info");
		
		System.out.println(info1);
	}

}
