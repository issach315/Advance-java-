package com.nonprimitive;

public class Engine
{
	
	private String eName;
	
	private int eModelNo;
	
	private double ePrice;
	
	private boolean eStatus;

	public Engine()
	{
		System.out.println("Engine start.....!");
	}

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public int geteModelNo() {
		return eModelNo;
	}

	public void seteModelNo(int eModelNo) {
		this.eModelNo = eModelNo;
	}

	public double getePrice() {
		return ePrice;
	}

	public void setePrice(double ePrice) {
		this.ePrice = ePrice;
	}

	public boolean iseStatus() {
		return eStatus;
	}

	public void seteStatus(boolean eStatus) {
		this.eStatus = eStatus;
	}

	@Override
	public String toString() {
		return "Engine [eModel=" + eName + ", eModelNo=" + eModelNo + ", ePrice=" + ePrice + ", eStatus=" + eStatus
				+ "]";
	}
	
	
	

}
