package com.ArrayDI;

public class SampleReverseNumProg 
{
	public static void main(String[] args)
	{
		int num=54321;
		int newNum=0;
		
		while(num>=0)
		{
			int lastDigit =num/10;
			
			newNum = newNum*10+lastDigit;
		}
		
		System.out.println(newNum);
		
	}

}
