package com.ArrayDI;

public class NotesArrayTypeDi 
{/*  same xml file we have different type of id for cpu bean
 * 
	   <bean id="cpu1" class="com.ArrayDI.Cpu">
        <property name="cpuGen" value="12th-Gen"></property> </bean>
        
        <bean id="cpu2" class="com.ArrayDI.Cpu">
        <property name="cpuGen" value="13th-Gen"></property>
        </bean>
               
        <bean id="cpu3" class="com.ArrayDI.Cpu">
        <property name="cpuGen" value="14th-Gen"></property>
        </bean>
               
        <bean id="laptop1" class="com.ArrayDI.Laptop">
        <property name="laptopBrands">
        
        <list>
        	<value>Asus</value>
        	<value>xiaomi</value>
        	<value>lenovo</value>
        </list>
        
        </property>
             
        <property name="cpu">
	        <list>
		        <ref bean="cpu1"/>
		        <ref bean="cpu2"/>
		        <ref bean="cpu3"/>
	        </list>
	    </property>
        </bean>
*/

}
