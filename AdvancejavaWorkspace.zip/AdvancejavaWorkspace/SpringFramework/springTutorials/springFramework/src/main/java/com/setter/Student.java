package com.setter;

public class Student
{
	private String stdName;
	
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}

	public void wish()
	{
		System.out.println("welcome Mr."+stdName);
	}

}
