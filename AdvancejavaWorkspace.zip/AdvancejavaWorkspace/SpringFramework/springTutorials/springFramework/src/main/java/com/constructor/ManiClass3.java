package com.constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ManiClass3
{
	public static void main(String[] args) 
	{
		// finding the XML file and loading the IOC container 
		ApplicationContext context = new ClassPathXmlApplicationContext("constructor.xml");
		
		// creating the bean for person class
		Person person1 =  (Person)context.getBean("person");
		
		//printing the person class properties
		System.out.println(person1);
		
	}

}
