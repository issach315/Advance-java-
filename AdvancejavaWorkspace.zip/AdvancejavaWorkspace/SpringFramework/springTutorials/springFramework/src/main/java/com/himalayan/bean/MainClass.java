package com.himalayan.bean;

import java.beans.beancontext.BeanContext;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass 
{
	public static void main(String[] args)
	{
		//find xml file load into container 
		BeanFactory factory = new ClassPathXmlApplicationContext("sample1.xml");
		
		
		//creating the Demo class object and loading the  
		Demo demo1 = (Demo)factory.getBean("demo");
		Demo demo2 = (Demo)factory.getBean("demo");
		Demo demo3 = (Demo)factory.getBean("demo");
	
		// printing the demo class properties
		demo1.hello();
		demo2.hello();
		demo3.hello();
		
		
		
	
		
		
		
		
	}

}
