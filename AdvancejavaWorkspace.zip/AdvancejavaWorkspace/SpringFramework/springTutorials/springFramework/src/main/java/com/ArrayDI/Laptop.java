package com.ArrayDI;

import java.util.Arrays;

public class Laptop
{
	private String[] laptopBrands;
	
	private Cpu[] cpu;

	public String[] getLaptopBrands() {
		return laptopBrands;
	}

	public void setLaptopBrands(String[] laptopBrands) {
		this.laptopBrands = laptopBrands;
	}

	public Cpu[] getCpu() {
		return cpu;
	}

	public void setCpu(Cpu[] cpu) {
		this.cpu = cpu;
	}
	
	public void laptopInfo()
	{
		for(String laptop:laptopBrands)
		{
			System.out.println(laptop);
		}
		
		for(Cpu cpus:cpu)
		{
			System.out.println(cpus.getCpuGen());
		}
	}

	@Override
	public String toString() {
		return "Laptop [laptopBrands=" + Arrays.toString(laptopBrands) + " " + Arrays.toString(cpu) + "]";
	}
	

}
