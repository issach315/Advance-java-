package com.nonprimitive;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ManiClass04 
{
	public static void main(String[] args)
	{
		
		String files[] =new String[] {"car.xml","Engine.xml"}; 
		
		ApplicationContext context = new ClassPathXmlApplicationContext("car.xml");
		
		Car car2 = (Car)context.getBean("car1");
		
		
		System.out.println(car2);
	}

}



