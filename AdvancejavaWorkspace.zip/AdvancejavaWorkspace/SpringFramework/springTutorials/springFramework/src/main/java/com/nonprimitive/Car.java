package com.nonprimitive;

public class Car 
{
	
	private Engine engine;
	
	private String carName;

	
	public Car()
	{
		System.out.println("car started....!");
	}
	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	@Override
	public String toString() {
		return "Car [engine=" + engine + ", carName=" + carName + "]";
	}
	
	
	

}
