package com.setter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass3
{
	public static void main(String[] args) 
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("sample2.xml");
		
		Student std = (Student)context.getBean("std1");
		
		std.wish();
		
	}

}
