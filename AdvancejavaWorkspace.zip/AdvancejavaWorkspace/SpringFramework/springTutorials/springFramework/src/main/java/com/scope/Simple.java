package com.scope;

public class Simple
{
	public Simple()
	{
		System.out.println("Default constructor.....");
	}

}
