package com.requiredCollectionDI;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass07 
{
	public static void main(String[] args)
	{
		// core conteainer not  is supporing for the schema base xml config   
		//then we are using the j2EE container 
		ApplicationContext context = new ClassPathXmlApplicationContext("requiredCollectionDI.xml");
		Information info1 = (Information)context.getBean("info");
		
		System.out.println(info1);
	}

}
