package com.ArrayDI;

public class Cpu 
{
	private String cpuGen;

	

	@Override
	public String toString() {
		return " [cpuGen=" + cpuGen + "]";
	}

	public String getCpuGen() {
		return cpuGen;
	}

	public void setCpuGen(String cpuGen) {
		this.cpuGen = cpuGen;
	}
	
	
	
	

}
