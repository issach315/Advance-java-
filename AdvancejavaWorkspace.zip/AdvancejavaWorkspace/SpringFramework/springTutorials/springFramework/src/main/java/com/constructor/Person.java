package com.constructor;

public class Person
{
	private String pName;
	
	private int pId;
	
	private double pSal;
	
	private boolean pStatus;

	public Person(String pName, int pId, double pSal, boolean pStatus) 
	{
		
		this.pName = pName;
		this.pId = pId;
		this.pSal = pSal;
		this.pStatus = pStatus;
	}

	@Override
	public String toString() {
		return "Person [pName=" + pName + ", pId=" + pId + ", pSal=" + pSal + ", pStatus=" + pStatus + "]";
	}
	
	
	
	
	
	

}
