package com.himalayan.bean;

public class Demo
{
	
	public Demo()
	{
		System.out.println("default constructor");
	}
	public void hello()
	{
		System.out.println("hello issach....!");
	}
}
