package com.CollectionDI;

public class NotesCollectionDI
{	
	/* List is main interface of all the list type Collection {ArrayList , LinkedList}
	 * 
	 * List list1 = new ArrayList();   
	 * List list2 = new LinkedList();
	 * 
	 * Set set1 = new HashSet();
	 * Set set2 = new LinkedHashSet();
	 * Set set3 = new TreeSet();
	 * 
	 * Map map1 = new HashMap();
	 * Map map2 = new LinkedHashMap();
	 * 
	 * 
	 *  <bean id="info" class="com.CollectionDI.Info">
       
      <!--List type collection dependency injection  --> 
      
       <property name="carNames">
       
      		 <list>
			        <value>BMW</value>
			        <value>Ferrari</value>
			        <value>Lamborgini</value>
      		 </list> 
      		 
       </property>
       
       
       
       
       <!--Set type collection dependency injection   -->
       
       <property name="bikeNames">
       
		     <set>
			       <value>YAMAHA</value>
			       <value>Bajaj</value>
			       <value>TVS</value>
		     </set>
		     
       </property>
       
       <!-- Map type collection dependency injection  -->
       
       <property name="mobileModel">
       
		       <map>
				     <entry key="s23" value="samsungUltraProMax"/>
				     <entry key="s22" value="samsungUltraPro"/>
				     <entry key="s21" value="samsungUltra"/>
		       </map>
		       
       </property>  
       
       </bean>
	  
	 * */

}
