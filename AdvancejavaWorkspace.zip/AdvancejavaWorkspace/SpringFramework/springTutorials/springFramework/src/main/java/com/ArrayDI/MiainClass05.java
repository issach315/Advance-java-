 package com.ArrayDI;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MiainClass05 
{

	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("ArraysDI.xml");
		
		Laptop laptop2 = (Laptop)context.getBean("laptop1");
		
		laptop2.laptopInfo();
		
		System.out.println(laptop2);
		
	}
}
