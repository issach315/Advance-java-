package org.jsp.application;

 import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
 import java.sql.DriverManager;
 import java.sql.PreparedStatement;
 import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
 import javax.servlet.annotation.WebServlet;
 import javax.servlet.http.HttpServlet;
 import javax.servlet.http.HttpServletRequest;
 import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 @WebServlet("/Assign1PwdClass")
 public class Assign1PwdClass extends HttpServlet
 {
 	@Override
 	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
 	{
 		String uPwd=req.getParameter("userPwd");
 		
 		System.out.println("User Password "+uPwd);
 		
 		HttpSession session =req.getSession();
 		
 		String sessionPwd =(String) session.getAttribute("userPassword");
 		
 		System.out.println("Sesssion password : "+sessionPwd);
 		
 		PrintWriter writer =resp.getWriter();
 		
 		if(uPwd.equals(sessionPwd))
 		{
 			RequestDispatcher dispatcher=req.getRequestDispatcher("Assign1LogIn.html");
 			dispatcher.include(req, resp);
 			writer.println("<center><h1> welcome "+(String)session.getAttribute("userName")+"</h1>");
 			writer.println("<h1 style='color:green;'>LogIn Successfull....</h1></center>");
 			
 			
 		}
 		else
 		{
 			RequestDispatcher dispatcher=req.getRequestDispatcher("Assign1Email.html");
 			dispatcher.include(req, resp);
 			writer.println("<h1 style='color:red;'>Invalid Password....!</h1>");
 			
 		}
 		
 		if (sessionPwd == null)
 		{
 			writer.println("<h1>please Enter password before 10 Sec  </h1>");
			
		}
 			
 		
 	}

 }
