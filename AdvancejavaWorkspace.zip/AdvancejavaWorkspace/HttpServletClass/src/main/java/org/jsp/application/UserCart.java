package org.jsp.application;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/UserCart")
public class UserCart extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String uEmail=req.getParameter("userEmail");
		
		String uPassword=req.getParameter("userPassword");
		
		String query="select * from tejm31_database.fb where fbpassword=? and userEmail=?";
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection =DriverManager.getConnection(url);
			PreparedStatement pstmt = connection.prepareStatement(query);
			
			pstmt.setString(1,uEmail);
			pstmt.setString(2,uPassword);
			
			PrintWriter writer=resp.getWriter();
			
			ResultSet rs = pstmt.executeQuery();
			
			if (rs.next())
			{
				resp.sendRedirect("https://www.amazon.com");
			}
			else
			{
				resp.sendRedirect("https://www.facebook.com");
				
				/*sendRedirect(URL/path ) ------>httpServlet  ;
				 * 1.can not print output of PrintWriter
				 *2.access web-pages outside and inside the project 
				 */
				
				
				/*RequestDispatcher ---> GenericServlet / HttpServlet
				 * 1.print the output of the PrintWriter
				 * 2.can not access the web-pages outside of project 
				 */
				
			}
			connection.close();
		} 
		catch (Exception e)
		{
			
			e.printStackTrace();
		}
		
		
		
	}

}
