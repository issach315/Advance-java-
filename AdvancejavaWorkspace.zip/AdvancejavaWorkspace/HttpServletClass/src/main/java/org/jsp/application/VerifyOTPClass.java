package org.jsp.application;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/VerifyOTPClass")
public class VerifyOTPClass extends HttpServlet
{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String uotp =req.getParameter("userOTP");
		int uOTP =Integer.parseInt(uotp);
		
		HttpSession session =req.getSession();
		
		int sessionOTP =(Integer) session.getAttribute("genOTP");
		
		PrintWriter writer =resp.getWriter();
		
		if (uOTP == sessionOTP) 
		{
			writer.println("OTP verified Successfully ..."+(String)session.getAttribute("Name"));
 		}
		else
 		{
 			
 			writer.println("<h1>please Enter password before 10 Sec  </h1>");
 			
 		}
 		
 		if (uOTP != sessionOTP)
 		{
 			RequestDispatcher dispatcher=req.getRequestDispatcher("MobileVerify.html");
 			dispatcher.include(req, resp);
 			writer.println("<h1 style='color:red;'>Invalid OTP....!</h1>");
			
		}
			
		
	}
	
}
