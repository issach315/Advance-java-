package org.jsp.application;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/FetchMobileNoClass")
public class FetchMobileNoClass  extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		String userMobile=req.getParameter("userMobileNo");
		
		// jdbc code
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from tejm31_database.fb where MobileNo=?";
		
		
			
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection =DriverManager.getConnection(url);
					PreparedStatement pstmt=connection.prepareStatement(query);
					pstmt.setString(1,userMobile);
					ResultSet  rs  =  pstmt.executeQuery();
					PrintWriter writer =resp.getWriter();
					
					if (rs.next())
					{
						Random random = new Random();
						int number=random.nextInt(1000000);
						System.out.println();
						
						if (number<100000)
						{
							number+=100000;
						}
//						RequestDispatcher dispatcher =req.getRequestDispatcher("VerifyOTP.html");
//						dispatcher.include(req, resp);
//						writer.println("<h1 style='color:blue;'>YOUR OTP is : </h1>"+number);
//						
						String name=rs.getString("fbName");
						
						HttpSession session=req.getSession();
						session.setAttribute("genOTP",number);
						session.setAttribute("Name", name);
						
						session.setMaxInactiveInterval(5);
						
						RequestDispatcher dispatcher =req.getRequestDispatcher("VerifyOTP.html");
						dispatcher.include(req, resp);
						writer.println("<h1 style='color:blue;'>YOUR OTP is : </h1>"+number);
							
					}
					
					
				}
				catch (Exception e) 
				{
					
					e.printStackTrace();
				}
			
			
			
				
				
		
	}

}
