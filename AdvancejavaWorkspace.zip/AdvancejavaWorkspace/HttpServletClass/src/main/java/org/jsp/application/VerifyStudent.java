package org.jsp.application;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/VerifyStudent")
public class VerifyStudent extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String temp =req.getParameter("rNo");
		int stdRno =Integer.parseInt(temp);
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from tejm31_database.student_table where rollNo=?";
		
		
		try 
		{
			// loading the jdbc drivers
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection=DriverManager.getConnection(url);
			PreparedStatement pstmt =connection.prepareStatement(query);
			pstmt.setInt(1, stdRno);
			
			ResultSet rs	=	pstmt.executeQuery();
			
			PrintWriter writer=resp.getWriter();
			
			if (rs.next())
			{
				writer.println("Student Name    : "+rs.getString("sname"));
				writer.println("Student Result  : "+rs.getDouble("result"));
				writer.println("Student Roll No : "+rs.getInt("rollNo"));
				
				
			}
			else
			{
				writer.println("<h1 style='color:red ;'>Invalid Roll No ....!</h1>");
			}
			connection.close();
		}
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
		
	}
}
