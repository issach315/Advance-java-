package org.jsp.application;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/Assign1EmailClass")
public class Assign1EmailClass extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{	//fetch email id from front-end
		String uEmail=req.getParameter("userEmail");
		
		//jdbc code 
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from tejm31_database.fb where userEmail=?";
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection =DriverManager.getConnection(url);
			PreparedStatement pstmt=connection.prepareStatement(query);
			pstmt.setString(1,uEmail);
			ResultSet rs =pstmt.executeQuery();
			PrintWriter writer=resp.getWriter();
			
			if (rs.next())
			{
				//Retrieve the data from the Database
				
				String name=rs.getString("fbName");
				String mobileNo =rs.getString("MobileNo");
				int id=rs.getInt("idfb");
				String uName=rs.getString("userName");
				String email=rs.getString("userEmail");
				String uPswd=rs.getString("fbPassword");
				writer.println("User data Fetch from Database.... :) ");
				
				// Access Session object 
			
				System.out.println("Session object accessed from JEE Container....  ");
				HttpSession session=req.getSession();
				//store the user data from the session object
				
				session.setAttribute("mail", email);
				session.setAttribute("mobileNum", mobileNo);
				session.setAttribute("fbId", id);
				session.setAttribute("userPswd",uPswd);
				session.setAttribute("usersName", uName);
				session.setAttribute("Name", name);
				System.out.println("user data stored in a session object.... ");
				
				// time interval
				session.setMaxInactiveInterval(20);
				//Perform servlet chaining
				RequestDispatcher dispatcher =req.getRequestDispatcher("Assign1Pwd.html");
				dispatcher.include(req, resp);
				writer.println("<h1 style='color:green;'>Email Verified...</h1>");	
				
			}
			else
			{
				// perform Servlet chaining
				RequestDispatcher dispatcher =req.getRequestDispatcher("Assign1Email.html");
				dispatcher.include(req, resp);
				writer.println("<h1 style='color:red;'>Invalid Email-Id ......!</h1>");
				
			}
			
			connection.close();
		} 
		catch (Exception e)
		{
			
			e.printStackTrace();
		}
		
	}

}
