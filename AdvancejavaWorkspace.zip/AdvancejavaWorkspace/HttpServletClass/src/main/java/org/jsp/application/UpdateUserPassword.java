package org.jsp.application;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/UpdateUserPassword")
public class UpdateUserPassword extends HttpServlet 
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		String mobileNo=req.getParameter("mNo");
		String newPwd=req.getParameter("newPwd");
		
		String oldPwd=req.getParameter("oldPwd");
		
		//jdbc
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		String query="UPDATE  tejm31_database.fb SET fbPassword=? WHERE MobileNo=? AND fbPassword=?";
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection connection =DriverManager.getConnection(url);
			
		PreparedStatement pstmt	= connection.prepareStatement(query);
		
		pstmt.setString(1,newPwd);
		pstmt.setString(2,mobileNo);
		pstmt.setString(3, oldPwd);
		
		
		
		int count =pstmt.executeUpdate();
		
		
		
		PrintWriter writer =resp.getWriter();
		if (count>0)
		{
			RequestDispatcher dispatcher =req.getRequestDispatcher("UserLogInFB.html");
			dispatcher.include(req, resp);
		
		} 
		else 
		{
			RequestDispatcher dispatcher =req.getRequestDispatcher("UpdatePassword.html");
			dispatcher.include(req, resp);
			writer.println("<h1 style='color:red;'>Invalid Mobile No ...!</h1>");
		}
			connection.close();
		} 
		catch(Exception e) 
		{
			
			e.printStackTrace();
		}
		
	}

}
