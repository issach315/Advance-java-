package org.jsp.application;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.mysql.jdbc.Connection;



@WebServlet("/EmployeeLogIn")
public class EmployeeLogIn extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		String temp =req.getParameter("id");
		
		int empId=Integer.parseInt(temp);
		
		//jdbc code
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		String query="select * from tejm31_database.emp where empId=?";
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection(url);
			
			PreparedStatement pstmt=connection.prepareStatement(query);
			
			pstmt.setInt(1,empId);
			
			ResultSet rs = pstmt.executeQuery();
			
			PrintWriter writer =resp.getWriter();
			
			
			
			if (rs.next())
			{
				//Servlet chaining - display employeeportal.html
				RequestDispatcher dispatcher=req.getRequestDispatcher("EmpPortal.html");
				dispatcher.include(req, resp);
				//print the message  Login successfull
				
				writer.println("<h1 style='color:green;'>LogIn Successfull..... :) "+"<br> Employee Name : "+rs.getString("EmpName")+"</h1>");
				
			}
			else
			{
				//servlet chaning disply EmployeeeLogin.html
				
				
				RequestDispatcher dispatcher=req.getRequestDispatcher("EmployeeSignIn.html");
				dispatcher.include(req, resp);
				
				//print the msg invalid credentitals  
				
				writer.println("<h1 style='color:red;'>please Enter Valid Employee Id .....!</h1>");
			}
			connection.close();
			
		} 
		catch (SQLException | ClassNotFoundException e) 
		{
			
			e.printStackTrace();
		}
		
		
	}
}
