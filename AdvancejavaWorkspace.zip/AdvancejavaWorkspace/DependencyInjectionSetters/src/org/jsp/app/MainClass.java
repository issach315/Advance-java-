package org.jsp.app;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass
{
  public static void main(String[] args)
  {
    ApplicationContext context=new ClassPathXmlApplicationContext("sample.xml");
    Car c=(Car) context.getBean("car");
    
    System.out.println("Name of the car  "+c.getNameOftheCar());
    System.out.println("Number of seats   "+c.getNumberOfSeats());
    System.out.println("Car number " +c.getCarNumber());
    System.out.println("Car price "+c.getCarPrice());
    
    System.out.println("---------------------------------");
    
    Car c1=(Car) context.getBean("car1");
    System.out.println("Name of the car "+c1.getNameOftheCar());
    System.out.println("Number of seats   "+c1.getNumberOfSeats());
    System.out.println("Car number " +c1.getCarNumber());
    System.out.println("Car price "+c1.getCarPrice());
    
    System.out.println("----------------------------------------");
    Car c2=(Car) context.getBean("car2");
    System.out.println("Name of the car "+c2.getNameOftheCar());
    System.out.println("Number of seats   "+c2.getNumberOfSeats());
    System.out.println("Car number " +c2.getCarNumber());
    System.out.println("Car price "+c2.getCarPrice());
    
    
    
   System.out.println("------*-------*------");
    
  
   
  }
}