package org.jsp.app;

public class Car
{
  private String nameOfTheCar;
  private int numberOfSeats;
  private int carNumber;
  private double carPrice;
  
  
  public String getNameOftheCar()
  {
    return nameOfTheCar;
  }
  public void setNameOfTheCar(String nameOfTheCar)
  {
    this.nameOfTheCar = nameOfTheCar;
  }
  public int getNumberOfSeats() 
  {
    return numberOfSeats;
  }
  public void setNumberOfSeats(int numberOfSeats)
  {
    this.numberOfSeats = numberOfSeats;
  }
  public int getCarNumber() 
  {
    return carNumber;
  }
  public void setCarNumber(int carNumber) 
  {
    this.carNumber = carNumber;
  }
  public double getCarPrice() 
  {
    return carPrice;
  }
  public void setCarPrice(double carPrice)
  {
    this.carPrice = carPrice;
  }
  
}