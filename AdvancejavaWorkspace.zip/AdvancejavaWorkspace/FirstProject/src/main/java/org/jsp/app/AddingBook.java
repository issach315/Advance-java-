package org.jsp.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

import com.mysql.jdbc.Connection;
@WebServlet("/AddingBook")
public class AddingBook extends GenericServlet
{

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException
	{
		String temp1=request.getParameter("bId");
		int bookId=Integer.parseInt(temp1);
		
		String bookTitle=request.getParameter("bTitle");
		
		String temp3=request.getParameter("bPages");
		
		int bookPages=Integer.parseInt(temp3);
		
		String temp4=request.getParameter("bPrice");
		
		int bookPrice=Integer.parseInt(temp4);
		
		String bookAuthor =request.getParameter("bAuthor");
		
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="insert into tejm31_database.book  values(?,?,?,?,?)";
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection connection =(Connection) DriverManager.getConnection(url);
			
		    PreparedStatement  pstmt	=connection.prepareStatement(query);
		    
		    pstmt.setInt(1,bookId);
		    pstmt.setString(2, bookTitle);
		    pstmt.setInt(3, bookPages);
		    pstmt.setInt(4, bookPrice);
		    pstmt.setString(5, bookAuthor);
		    
		  int status=  pstmt.executeUpdate();
		    
		    PrintWriter writer=response.getWriter();
		    
		    if (status>0)
		    {
		    	writer.println("<h1 style='color:green;'>Book Added Success....... :)</h1>");
				
			}
		    
		    connection.close();
		    
		} 
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
		
		
	}
	

}
