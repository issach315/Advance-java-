package org.jsp.app;

import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/EmpRegistationForm")

public class EmpRegistationForm extends GenericServlet
{

	@Override
	public void service(ServletRequest request, ServletResponse response)
			throws ServletException, IOException {
		
		
		/* getParameter(identifier of inputbox) - present in servletRequest Interface return type id string type */
		
		String temp1=request.getParameter("eid");
		int EmpId=Integer.parseInt(temp1);
		
		String temp2=request.getParameter("ename");
		String temp3=request.getParameter("esal");
		/* conerting string to doublr*/
		double EmpSalary=Double.parseDouble(temp3);
		
		String temp4 =request.getParameter("edept");
		
		int EmpDeptNo =Integer.parseInt(temp4);
		
		PrintWriter writer =response.getWriter();
		writer.println("Employee Name    : "+temp2);
		writer.println("Employee Id      : "+EmpId);
		
		writer.println("Employee Salary  : "+EmpSalary);
		
		writer.println("Employee Dept No : "+EmpDeptNo);
		
		
		String query="insert into tejm31_database.emp values(?,?,?,?)";
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection =DriverManager.getConnection(url);
			
			PreparedStatement pstmt =connection.prepareStatement(query);
			
			pstmt.setInt(1, EmpId);
			pstmt.setString(2,temp2);
			pstmt.setDouble(3, EmpSalary);
			pstmt.setInt(4, EmpDeptNo);
			
			pstmt.executeUpdate();
			writer.println("<h1 style='color:green;'> Registration Success </h1>");
		}
		catch (SQLException | ClassNotFoundException e)
		{
			
			e.printStackTrace();
		}
		
		
	
		
		
		
		
		
	}
	

}
