package org.jsp.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/BookByAuthor")
public class BookByAuthor extends GenericServlet
{

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException 
	{
		String author =request.getParameter("book");
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		String query="select * from tejm31_database.book where bookAuthour=? ";
		
		try 
		{
			// loading the Driver 
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection connection = DriverManager.getConnection(url);
			PreparedStatement pstmt=connection.prepareStatement(query);
			
			pstmt.setString(1, author);
			
			ResultSet rs =pstmt.executeQuery();
			PrintWriter writer =response.getWriter();
			
			if (rs.last())
			{
				rs.beforeFirst();
				
				while(rs.next())
				{
					writer.println("Book Author Name : "+rs.getString("bookAuthour"));
					writer.println("Book  Name       : "+rs.getString("bookTitle"));
					writer.println("Book Price       : "+rs.getInt("bookPrice"));
					writer.println("Book Id          : "+rs.getInt("bookId"));
					writer.println("Book pages       : "+rs.getInt("bookPages"));
					
				}
				
			}
			connection.close();
		} 
		catch (Exception  e) 
		{
			
			e.printStackTrace();
		}
		
		
	}

}
