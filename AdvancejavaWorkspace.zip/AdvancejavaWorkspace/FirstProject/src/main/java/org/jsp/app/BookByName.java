package org.jsp.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/BookByName")
public class BookByName extends GenericServlet
{

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException 
	{
String title =request.getParameter("book");
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		String query="select * from tejm31_database.book where bookTitle=? ";
		
		try 
		{
			// loading the Driver 
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection connection = DriverManager.getConnection(url);
			PreparedStatement pstmt=connection.prepareStatement(query);
			
			pstmt.setString(1, title);
			
			ResultSet rs =pstmt.executeQuery();
			PrintWriter writer =response.getWriter();
			
			if (rs.last())
			{
				rs.beforeFirst();
				
				while(rs.next())
				{
					writer.println("Book Author Name : "+rs.getString("bookAuthour"));
					writer.println("Book  Name       : "+rs.getString("bookTitle"));
					writer.println("Book Price       : "+rs.getInt("bookPrice"));
					writer.println("Book Id          : "+rs.getInt("bookId"));
					writer.println("Book pages       : "+rs.getInt("bookPages"));
					
				}
				
			}
			connection.close();
		} 
		catch (Exception  e) 
		{
			
			e.printStackTrace();
		}
		
		
		
	}

}
