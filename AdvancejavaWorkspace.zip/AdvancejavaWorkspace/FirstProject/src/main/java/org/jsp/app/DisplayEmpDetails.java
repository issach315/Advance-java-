package org.jsp.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/DisplayEmpDetails")
public class DisplayEmpDetails extends GenericServlet
{

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException 
	{
		
		String temp1=request.getParameter("dept");
		int empdept=Integer.parseInt(temp1);
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from tejm31_database.emp where empDeptNo=?";
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection connection =DriverManager.getConnection(url);
			
			PreparedStatement pstmt=connection.prepareStatement(query);
			
			pstmt.setInt(1, empdept);
			
			ResultSet rs = pstmt.executeQuery();
			
			PrintWriter writer =response.getWriter();
			
			if(rs.last())
			{
				rs.beforeFirst();
				
				while(rs.next())
				{
					writer.println("Employee Name      : "+rs.getInt("empId"));
					writer.println("Employee Name      : "+rs.getString("empName"));
					writer.println("Employee Salary    : "+rs.getInt("empSal"));
					writer.println("Employee Dept No   : "+rs.getInt("empDeptNo"));
					
					writer.println("<h1 style='color:green;'>___________________________</h1>");
					
				}
				
			}
			else
			{
				writer.println("<h1 style='color:green;'>Invalid Department No</h1>");
			}
			connection.close();
			
		} 
		catch (Exception e)
		{
			
			e.printStackTrace();
		}
		
		
	}
	

}
