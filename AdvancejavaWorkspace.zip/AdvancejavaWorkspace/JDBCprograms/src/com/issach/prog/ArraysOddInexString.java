
package com.issach.prog;


public class ArraysOddInexString
{
	 

	
	public static void main(String[] args)
	{
		String name ="my name is issach  emani";
		
		
		
		
		for (int i = 0; i <name.length(); i++)
		{
			char ch=name.charAt(i);
			
			if(i%2 != 0 && ch>='a' && ch<='z' )
			{
				
				System.out.print(name.charAt(i));
			}
			
		}
		
	}
}
