package org.jsp.application;
import java.sql.*;
public class UpadateTheRecord 
{
	

	public static void main(String[] args)
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query=" update  tejm31_database.student_table set  percentage=78.89  where rollNo ='25'";
		
		try {
			Connection connect =DriverManager.getConnection(url);
			Statement stmt =connect.createStatement();
			 stmt.executeUpdate(query);
			 int updated =stmt.executeUpdate(query);
			 
			 System.out.println("updated :"+updated);
			 
			 if (updated>0)
			 {
				 System.out.println("Updated");
				
			} 
			 else
			{
				 System.err.println("no updates...!");
				 

			}
			
			
			 connect.close();
			
		} 
		catch (SQLException e) 
		{
		
			e.printStackTrace();
		}
		
		
	}

}
