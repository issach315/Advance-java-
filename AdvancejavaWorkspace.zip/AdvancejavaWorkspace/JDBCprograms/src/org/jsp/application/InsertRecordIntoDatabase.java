package org.jsp.application;
import java.sql.*;
public class InsertRecordIntoDatabase
{
	public static void main(String[] args) 
	{
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="INSERT INTO tejm31_database.student_table values(205,'Jagadesh',88.65,'AME')";
		
try {
//	step -1]:- get connection establishing
	Connection connection=DriverManager.getConnection(url);
	System.out.println("Connection Established");
	
	
	//Step-2 :-create platform
	Statement stmt =connection.createStatement();
	System.out.println("platform created...");
	
	//step-3:Execution of query
	stmt.executeUpdate(query);
	System.out.println("Query Recorded....");
	
	//step-5:- close the connection
	connection.close();
	System.out.println("connection closed..!");
	}
	catch (SQLException e)
	{
			e.printStackTrace();
	}
		
	}

}
