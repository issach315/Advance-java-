package org.jsp.application;
import java.sql.*;
public class EstablishConnection
{
	public static void main(String[] args)
	{
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
	try {
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Successfully....");
	}
	catch (SQLException e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
	}
}
