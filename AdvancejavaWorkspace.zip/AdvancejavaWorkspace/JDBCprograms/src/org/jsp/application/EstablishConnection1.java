package org.jsp.application;


import java.sql.*;



public class EstablishConnection1
{
	public static void main(String[] args) 
	{
		String url="jdbc:mysql://localhost:3306";
		String username="root";
		String password="12345";
		
		
		
			try {
//				step-1 :- get Connection
				
				Connection conn=DriverManager.getConnection(url,username,password);
				System.out.println("SuccessFull...");
				
//				Step -2:- Create a platform
				Statement stmt = conn.createStatement();
				System.out.println("paltform created...");
				
			}
			catch (SQLException e) 
			{
				
				e.printStackTrace();
			}
			System.out.println("Successfully Connected to JDBC");
		
		
	}

}
