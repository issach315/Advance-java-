package org.jsp.application;

import java.sql.*;

public class DeleteRecord
{
public static void main(String[] args)
{
	String url="jdbc:mysql://localhost:3306?user=root&password=12345";
	
	String query="delete from tejm31_database.student_table where rollNo=201";
	
	try {
		Connection connection =DriverManager.getConnection(url);
		Statement stmt =connection.createStatement();
	
		int noOfRecord =stmt.executeUpdate(query);
		
		System.out.println("Status : "+noOfRecord);
		if (noOfRecord>0)
		{
			System.out.println("Deleted.....");
			
		}
		else
		{
			System.err.println("no records Found...!");
		}
		connection.close();
	}
	catch (SQLException e) 
	{
		
		e.printStackTrace();
	}
	
	
}

}
