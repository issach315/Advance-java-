package org.jsp.application;

import java.sql.*;

public class TeacherTable 
{
	public static void main(String[] args) 
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="update tejm31_database.student_table set  percentage=99.09  where rollNo =202";
		try 
		{
			Connection conn=DriverManager.getConnection(url);
			Statement stmt=conn.createStatement();
			stmt.executeUpdate(query);
			stmt.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
}
