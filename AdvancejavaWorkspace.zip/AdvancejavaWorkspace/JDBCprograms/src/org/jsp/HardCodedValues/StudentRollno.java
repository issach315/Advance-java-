package org.jsp.HardCodedValues;
import java.sql.*;
public class StudentRollno 
{
	public static void main(String[] args)
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query ="select rollNo,stream,sname,percentage from tejm31_database.student_table where rollNo=202";
		
		try {
			Connection connection =DriverManager.getConnection(url);
			Statement stmt =connection.createStatement();
		ResultSet rs =	stmt.executeQuery(query);
		if (rs.next())
		{
		int stdRollNo=	rs.getInt("rollNo");
		double stdPer=rs.getDouble("percentage");
			
		String stdName =rs.getString("sname");
		String stream =rs.getString("stream");
		
		System.out.println(" Student Roll No    : "+stdRollNo);
		System.out.println(" student percentage : "+stdPer);
		System.out.println(" student Name       : "+stdName);
		System.out.println(" Student stram      : "+stream);
		}
		else
		{
			System.err.println("enter vaild Roll No.....!");

		}
			connection.close();
		}
		
		catch (SQLException e)
		{
			
			e.printStackTrace();
		}
	}

}
