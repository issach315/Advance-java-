package org.jsp.HardCodedValues;
import java.sql.*;
public class EmpSalAbove20000 
{
	public static void main(String[] args)
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from tejm31_database.employee where empSal>20000";
		
		try {
			Connection connection = DriverManager.getConnection(url);
			Statement stmt =connection.createStatement();
			ResultSet rs =stmt.executeQuery(query);
			while (rs.next())
			{
				int id =rs.getInt("empId");
				String name=rs.getString("empName");
				int sal=rs.getInt("empSal");
				int dept=rs.getInt("empDept");
				String mobile=rs.getString("empMobieNo");
				String location=rs.getString("emploc");
				int bonus=rs.getInt("empBonus");
				
				System.out.println(" Employee id        : "+id);
				System.out.println(" Employee name      : "+name);
				System.out.println(" Employee Loc       : "+sal);
				System.out.println(" Employee deptNo    : "+dept);
				System.out.println(" Employee mobile No : "+mobile);
				System.out.println(" Employee bonus     : "+bonus);
				System.out.println(" Employee Salary    : "+sal);
				System.err.println("________________________________");
				
			}
			connection.close();
		}
		catch (SQLException e)
		{
			
			e.printStackTrace();
		}
		
		
	}

}
