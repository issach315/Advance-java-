package org.jsp.HardCodedValues;
import java.sql.*;
public class EmpIdChecking 
{
	public static void main(String[] args)
	{

		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from tejm31_database.fb where fbMobileNo='9542966422' and fbPassword='issach@22'";
//		String query="select * from tejm31_database.student_table where stream='AME'";
//		String query="update  tejm31_database.student_table set stream='MECH' where rollNo%2!=0 ";
		
//		String query="delete from tejm31_database.employee where eName like'h%'";
			try {
				//connected to Database
				Connection connect =DriverManager.getConnection(url);
				//creating the platform
				Statement stmt =connect.createStatement();
				//checking the if employee is present or not for that "select-query is used " 
				ResultSet rs =stmt.executeQuery(query);	
			if (rs.next())
			{
				System.out.println("record is present ");
				
			} 
			else
			{
				System.err.println("invaild empId ");
			}
				
			stmt.close();
				
			} 
			catch (SQLException e)
			{
				
				e.printStackTrace();
			}
	}

	
	}


