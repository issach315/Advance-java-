package org.jsp.HardCodedValues;
import java.sql.*;
public class UsernameOfFBAccount 
{
	public static void main(String[] args)
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select userName from tejm31_database.fb where userEmail='issachemani227@gamil.com' and MobileNo='9542966422'";
		
		try {
			
			Connection connection = DriverManager.getConnection(url);
			
			Statement stmt =connection.createStatement();
			ResultSet rs 	=stmt.executeQuery(query);
			
			if (rs.next())
			{
				String user =rs.getString("userName");
				
				System.out.println("User Name is : "+user);
				
			}
			else
			{
				System.err.println("invalid");

			}
			connection.close();
			
		}
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
	}

}
