package org.jsp.HardCodedValues;
import java.sql.*;
public class FetchOddEmpId
{
	public static void main(String[] args) 
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
//		String query="select userName from tejm31_database.fb where userName like '%o%'";
		String query="select empId from tejm31_database.employee where empId%2 !=0";
		
		try
		{
			Connection connection=DriverManager.getConnection(url);
			Statement stmt	=connection.createStatement();
			
			ResultSet rs =stmt.executeQuery(query);
			
			if (rs.last())
			{
				rs.beforeFirst();
				while(rs.next())
				{
					System.out.println(" empId  : "+rs.getString("empId"));

					
				}
				
			} 
			else
			{
				System.err.println("Invalid user name ");

			}
			
			connection.close();
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
		
	}
	

}

