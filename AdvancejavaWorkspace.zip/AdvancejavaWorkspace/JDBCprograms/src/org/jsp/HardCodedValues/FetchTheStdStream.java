package org.jsp.HardCodedValues;
import java.sql.*;
public class FetchTheStdStream
{
	public static void main(String[] args)
	{
		
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from tejm31_database.student_table where stream='CSE'";
		
		Connection connection;
		try {
			connection = DriverManager.getConnection(url);
			Statement stmt =connection.createStatement();
			
			ResultSet  rs =stmt.executeQuery(query);
			if (rs.last())
			{
				
				rs.beforeFirst();
				
				
				while (rs.next())
				{
					
					System.out.println(" Student Roll No    : "+rs.getInt("rollNo"));
					System.out.println(" Student Name       : "+rs.getString("sname"));
					System.out.println(" Student Percentage : "+rs.getDouble("result"));
					System.out.println(" Student Stream     : "+rs.getString("stream"));
					System.out.println("________________________________");
				}	
			}
		
			else
			{
					System.err.println(" Invaild Stream....! ");
			}
			
			connection.close();
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
		
		
		
	}

}
