package org.jsp.StoredProcedure;
import java.util.*;
import java.sql.*;
public class InsertStdRecordSP
{
	public static void main(String[] args) 
	{
		
		String url ="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		try
		{
			Connection connection =DriverManager.getConnection(url);
			CallableStatement cstmt=connection.prepareCall("call tejm31_database.insertStdRecord(?,?,?,?)");
			
//			Assign values for placeholder
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Student Roll No");
			cstmt.setInt(1,sc.nextInt());
			
			System.out.println("Enter Student Name   ");
			cstmt.setString(2,sc.next());
			
			System.out.println("Enter Student percentage ");
			cstmt.setDouble(3,sc.nextDouble());
			
			System.out.println("Enter Student Stream ");
			cstmt.setString(4,sc.next());
			
			//execute the query
			
			int count =cstmt.executeUpdate();
			
			if (count>0)
			{
				System.out.println("Record is inserted Successfully.... :)");
				
			} 
			else
			{
				
				System.err.println("Invalid Enter...!");

			}
			connection.close();
			
			
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
	}

}
