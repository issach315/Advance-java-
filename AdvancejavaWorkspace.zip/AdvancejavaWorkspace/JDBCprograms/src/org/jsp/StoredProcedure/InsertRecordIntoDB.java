package org.jsp.StoredProcedure;
import java.sql.*;
public class InsertRecordIntoDB
{
	public static void main(String[] args) {
		
	}
}
