package org.jsp.StoredProcedure;
import java.sql.*;
import java.util.*;
public class AssingDisplayDetailsOfUser
{
	public static void main(String[] args) 
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		try
		{
			Connection connection=DriverManager.getConnection(url);
			
			CallableStatement cstmt =connection.prepareCall("call tejm31_database.displayFbUserDetails(?,?)");
			
			//Assign values to placeholder
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter user Email ");
			cstmt.setString(1,sc.next());
			
			System.out.println("Enter user Password ");
			cstmt.setString(2,sc.next());
			
			ResultSet rs = cstmt.executeQuery();
			
			if (rs.last())
			{
				rs.beforeFirst();
				
				while(rs.next())
				{
					System.out.println(" User Name   : "+rs.getString("fbName"));
					System.out.println(" User Id     : "+rs.getInt("idfb"));
				}
				
			}
			
			connection.close();
		}
		catch (SQLException e)
		{
			
			e.printStackTrace();
		}
				
		
	}

}
