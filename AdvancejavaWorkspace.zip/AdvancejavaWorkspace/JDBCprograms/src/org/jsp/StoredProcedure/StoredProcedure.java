package org.jsp.StoredProcedure;
import java.sql.*;
public class StoredProcedure
{
	public static void main(String[] args)
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		try
		{
			Connection connection = DriverManager.getConnection(url);
			CallableStatement cstmt=connection.prepareCall("call tejm31_database.deleteRecord");
			
			int count=cstmt.executeUpdate();
			if (count>0)
			{
				System.out.println("Record is Deleted....:)");
				
			} 
			else
			{
					System.err.println(" Invalid Student Roll No....!");
			}
			connection.close();
		} 
		catch (SQLException e)
		{
			
			e.printStackTrace();
		}
		
		
	}

}
