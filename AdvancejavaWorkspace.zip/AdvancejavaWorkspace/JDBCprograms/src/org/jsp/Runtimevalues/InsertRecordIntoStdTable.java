package org.jsp.Runtimevalues;
import java.sql.*;
import java.util.Scanner;

public class InsertRecordIntoStdTable
{
	public static void main(String[] args)
	{
		String url ="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="insert into tejm31_database.student_table values(?,?,?,?)";
		
		try 
		{
			//establishing the connection
			Connection connection =DriverManager.getConnection(url);
			//creating prepared type platform
			PreparedStatement pstmt =connection.prepareStatement(query);
			//taking input from user
			Scanner sc = new Scanner(System.in);
			
			System.out.println(" Enter student Roll No");
			int rNo =sc.nextInt();
			pstmt.setInt(1, rNo);
			
			System.out.println(" Enter student Name");
			String name =sc.next();
			pstmt.setString(2,name);
			
			System.out.println(" Enter student Result");
			double res=sc.nextDouble();
			pstmt.setDouble(3, res);
			
			System.out.println(" Enter student Stream ");
			String stream=sc.next();
			pstmt.setString(4,stream );
			
			pstmt.executeUpdate();
			
			System.out.println("Record is insertd Successfully.....");
			
			connection.close();
		
		}
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
		
	}

}
