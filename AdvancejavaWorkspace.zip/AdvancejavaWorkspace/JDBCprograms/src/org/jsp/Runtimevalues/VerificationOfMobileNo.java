package org.jsp.Runtimevalues;
import java.util.*;
import java.sql.*;
public class VerificationOfMobileNo 
{
	public static void main(String[] args)
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from tejm31_database.fb where MobileNo=?";
		
		try 
		{
			Connection connection = DriverManager.getConnection(url);
			PreparedStatement	pstmt=connection.prepareStatement(query);
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter your Mobile No ");
			pstmt.setString(1,sc.next());
			
			ResultSet rs = pstmt.executeQuery();
				
				if (rs.next())
					{
						// generation of OTP 4 digits 
						Random random=new Random();
						int otp =random.nextInt(10000);
						if (otp<1000)
						{
							otp=otp+1000;	
						} 
						System.out.println(" welcome          : "+rs.getString("fbName"));
						System.out.println(" Your OTP is      : "+otp);
						System.out.println(" Enter displed OTP: "); 
						
						int uotp=sc.nextInt(); 
						//scanning the user entered otp
						if (otp==uotp)
							{
								// user entered valid otp 
								System.out.println("your mobile No is verified...:)");
							} 
							else 
							{
								//if user entered invalid otp
								System.err.println("Enter valid OTP");
							}
							
						
					}
					else
					{
						//if user entered invalid mobile number
						System.err.println("No Recods Found....!");
					}
				
				connection.close();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		
	}

}
