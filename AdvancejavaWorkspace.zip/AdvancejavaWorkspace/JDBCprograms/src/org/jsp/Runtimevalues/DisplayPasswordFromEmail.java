package org.jsp.Runtimevalues;
import java.sql.*;
import java.util.*;
public class DisplayPasswordFromEmail 
{
	public static void main(String[] args)
	{
		String url ="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select fbPassword from tejm31_database.fb   where userEmail=? ";
		
		try
		{
			Connection connection =DriverManager.getConnection(url);
		PreparedStatement pstmt = connection.prepareStatement(query);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your email id ");
		String id=sc.next();
		pstmt.setString(1, id);
		
		ResultSet rs =pstmt.executeQuery();
		
		if (rs.last())
		{
			rs.beforeFirst();
			
			while(rs.next())
			{
				System.out.println(" Your Account Password is : "+rs.getString("fbPassword"));
				
			}
			
		}
		else 
		{
			System.err.println("Invaild Email...!");

		}
		connection.close();
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
				
		
	}

}
