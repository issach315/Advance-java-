package org.jsp.Runtimevalues;
import java.util.*;
import java.sql.*;
public class DleteRecordBasedOnThePassANDUName 
{
	public static void main(String[] args)
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		String query="delete from  tejm31_database.fb  where idfb=?  and fbPassword=? ";
		
		try
		{
			Connection connection =DriverManager.getConnection(url);
			
		PreparedStatement pstmt = connection.prepareStatement(query);
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your Fb Id");
		int fbId=sc.nextInt();
		pstmt.setInt(1, fbId);
		
		System.out.println("Enter your password ");
		String pass=sc.next();
		pstmt.setString(2, pass);
		
	int status=	pstmt.executeUpdate();
	
	if (status>0)
	{
		System.out.println("Record is Deleted...! ");
		
	} 
	else 
	{
		System.err.println("Invalid user And Password");

	}
	
	connection.close();
	
		
		}
		catch (SQLException e)
		{
			
			e.printStackTrace();
		}
		
	}

}
