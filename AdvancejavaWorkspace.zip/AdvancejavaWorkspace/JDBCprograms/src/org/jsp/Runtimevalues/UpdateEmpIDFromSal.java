package org.jsp.Runtimevalues;
import java.util.*;
import java.sql.*;
public class UpdateEmpIDFromSal
{
	public static void main(String[] args) 
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		String query="update  tejm31_database.employee set empSal= ?  where empId = ? ";
		
		try 
		{
			Connection connection =DriverManager.getConnection(url);
			
			PreparedStatement pstmt=connection.prepareStatement(query);
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter updated emp sal ");
			int sal=sc.nextInt();
			pstmt.setInt(1, sal);
			
			
			System.out.println("Enter Employee ID ");
			int id =sc.nextInt();
			pstmt.setInt(2,id);
			
		
			int status =pstmt.executeUpdate();
			if (status > 0)
			{

				System.out.println("employee Salary is updated");
				
			} 
			else 
			{
				System.err.println("Invalid Employee Id");
			}
			
			
			connection.close();
			
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
				
		
	}

}
