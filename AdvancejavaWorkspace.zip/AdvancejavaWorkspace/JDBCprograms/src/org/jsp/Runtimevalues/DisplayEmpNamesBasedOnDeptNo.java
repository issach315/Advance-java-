package org.jsp.Runtimevalues;
import java.sql.*;
import java.util.*;
public class DisplayEmpNamesBasedOnDeptNo
{
	public static void main(String[] args)
	{
		String url ="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from tejm31_database.employee where empDept= ?";
		
		try 
		{
			Connection connection =DriverManager.getConnection(url);
			PreparedStatement pstmt =connection.prepareStatement(query);
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Employee DeptNo");
			int dept=sc.nextInt();
			pstmt.setInt(1, dept);
			
		
			ResultSet rs =pstmt.executeQuery();
			
			if (rs.last())
			{
				//Retrieve the fetching data 
				rs.beforeFirst();
				
				while(rs.next())
				{
					System.out.println(" Employee Name   : "+rs.getString("empName"));
					System.out.println(" Employee DeptNO : "+rs.getInt("empDept"));
					System.out.println("____________________________________");
					
				}
				
			} 
			else
			{
					System.err.println("Record is Not Found...!");
			}
		
		
		connection.close();
		} 
		catch (SQLException e)
		{
			
			e.printStackTrace();
		}
		
		
	}

}
