package org.jsp.app;

public class Person
{
	private String name;
	private int age;
	private String gen;
	
	
	public Person(String name) 
	{
		
		this.name = name;
		
		
	}
	
	public Person(String name,int age) 
	{
		
		this.name = name;
		this.age=age;
		
	}
	public Person(String name,int age,String gen) 
	{
		
		this.name = name;
		this.age=age;
		this.gen=gen;
		
	}
	
	public void deatils() 
	{
		
		System.out.println("Person Name  : "+name);
		System.out.println("Age          : "+age);
		System.out.println("Person gender : "+gen);
		
	}
	
	

}
