package com.firstAdvancejava.project;
import java.util.*;

public class Generation8DigitOTP

{
	public static void main(String[] args) {
		
		
		Random random = new Random();
		int number=random.nextInt(1000000);
		System.out.println();
		
		if (number<100000)
		{
			number+=100000;
			System.out.println(" your OTP is :"+number);
			
		}
		
	}

}
