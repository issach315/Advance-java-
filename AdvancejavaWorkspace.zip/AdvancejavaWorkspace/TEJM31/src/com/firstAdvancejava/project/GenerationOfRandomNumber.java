package com.firstAdvancejava.project;

import java.util.Random;
import java.util.Scanner;

public class GenerationOfRandomNumber 
{
	public static void main(String[] args) 
	{
		//Random Number
		
		Random random = new Random();
		
		int number=random.nextInt(9999);
		
		System.out.println("Random number = "+number);
		
		if (number<1000)
		{		
			//converting into 4digit number 
			number+=1000;
		}
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Your OTP");
		int userOTP =scan.nextInt();
		
		if (number==userOTP)
		{
			System.out.println("OTP is Verified Succesfully... :)");
			
		} 
		else
		{
			System.err.println("Invalid OTP...!");
		}
		
		
	}

}
