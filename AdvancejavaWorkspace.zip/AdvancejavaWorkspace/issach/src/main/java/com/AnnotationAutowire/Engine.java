package com.AnnotationAutowire;

public class Engine
{
	
	private String eType;
	private String eModel;
	@Override
	public String toString() {
		return "Engine [eType=" + eType + ", eModel=" + eModel + "]";
	}
	
	
	

}
