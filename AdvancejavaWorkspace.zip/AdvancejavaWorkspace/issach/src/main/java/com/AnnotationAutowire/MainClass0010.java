package com.AnnotationAutowire;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass0010 
{
	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("annotAutowire.xml");
		
		Bus bus2 = (Bus)context.getBean("bus1");
		
		System.out.println(bus2);
	}

}
