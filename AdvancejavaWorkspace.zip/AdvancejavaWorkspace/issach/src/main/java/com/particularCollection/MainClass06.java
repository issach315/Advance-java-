package com.particularCollection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass06
{
	public static void main(String[] args) 
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("particularCollectionDI.xml");
		
		Test1 test2 =(Test1)context.getBean("test1");
		
		System.out.println(test2.toString());
	}

}
