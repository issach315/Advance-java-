package com.particularCollection;

import java.util.*;

public class Test1 
{
	private Vector names;
	private Set ages;
	
	public void setNames(Vector names) {
		this.names = names;
	}
	
	public void setAges(Set ages) {
		this.ages = ages;
	}
	@Override
	public String toString() {
		return "Test1 [names=" + names + ", ages=" + ages + "]";
	}
	
	
}
