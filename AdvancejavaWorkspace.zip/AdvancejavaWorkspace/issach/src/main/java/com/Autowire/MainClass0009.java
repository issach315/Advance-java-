package com.Autowire;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass0009 
{
	public static void main(String[] args) 
	{
		
		ApplicationContext context = new ClassPathXmlApplicationContext("Autowire.xml");
		
		Mobile mobile = (Mobile)context.getBean("m1");
		
		System.out.println(mobile);
	}

}
