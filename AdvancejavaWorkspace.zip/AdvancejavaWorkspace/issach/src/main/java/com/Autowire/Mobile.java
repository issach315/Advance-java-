package com.Autowire;

public class Mobile 
{
	private String mobileBrand;
	private Sim sim;
	public String getMobileBrand() {
		return mobileBrand;
	}
	public void setMobileBrand(String mobileBrand) {
		this.mobileBrand = mobileBrand;
	}
	public Sim getSim() {
		return sim;
	}
	public void setSim(Sim sim) {
		this.sim = sim;
	}
	@Override
	public String toString() {
		return "Mobile [mobileBrand=" + mobileBrand + ", sim=" + sim + "]";
	}
	
	

}
