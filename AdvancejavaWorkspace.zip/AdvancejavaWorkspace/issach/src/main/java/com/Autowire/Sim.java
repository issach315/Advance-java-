package com.Autowire;

public class Sim 
{
	private String simNo;
	
	private String networkType;

	public String getSimNo() {
		return simNo;
	}

	public void setSimNo(String simNo) {
		this.simNo = simNo;
	}

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	@Override
	public String toString() {
		return "Sim [simNo=" + simNo + ", networkType=" + networkType + "]";
	}
	
	
	

}
