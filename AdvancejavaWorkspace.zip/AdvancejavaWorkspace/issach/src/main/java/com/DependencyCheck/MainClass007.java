package com.DependencyCheck;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass007 
{
	public static void main(String[] args) 
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("DependencyCheck.xml");
		
		Mobile mobile = (Mobile)context.getBean("mobile1");
		
		System.out.println(mobile);
	}

}
