package com.DependencyCheck;

public class Sim 
{
	private String networkName;
	
	private String simNo;

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public String getSimNo() {
		return simNo;
	}

	public void setSimNo(String simNo) {
		this.simNo = simNo;
	}

	@Override
	public String toString() {
		return "Sim [networkName=" + networkName + ", simNo=" + simNo + "]";
	}
	
	

}
