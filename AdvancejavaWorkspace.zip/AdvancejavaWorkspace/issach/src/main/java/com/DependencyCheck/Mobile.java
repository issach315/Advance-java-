package com.DependencyCheck;

public class Mobile
{
	private Sim sim;
	
	private String MobileBrand;

	public Sim getSim() {
		return sim;
	}

	public void setSim(Sim sim) {
		this.sim = sim;
	}

	public String getMobileBrand() {
		return MobileBrand;
	}

	public void setMobileBrand(String mobileBrand) {
		MobileBrand = mobileBrand;
	}

	@Override
	public String toString() {
		return "Mobile [sim=" + sim + ", MobileBrand=" + MobileBrand + "]";
	}
	
	
	
	
	

}
