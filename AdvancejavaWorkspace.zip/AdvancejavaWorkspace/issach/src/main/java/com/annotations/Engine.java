package com.annotations;

public class Engine 
{
	private String eName;

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	
	
	

}
