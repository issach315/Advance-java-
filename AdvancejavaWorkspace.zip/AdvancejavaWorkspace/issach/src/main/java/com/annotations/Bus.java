package com.annotations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Bus 
{
	@Autowired
	private Engine engine;

	void dataDisplay()
	{
		System.out.println(" Bus Name : "+engine.geteName());
	}
	
	
	

}
