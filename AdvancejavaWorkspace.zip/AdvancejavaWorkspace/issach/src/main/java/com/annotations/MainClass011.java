package com.annotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass011 
{
	public static void main(String[] args) 
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("springAnnotations.xml");
		
		Bus b1 = (Bus)context.getBean(Bus.class);
		
		b1.dataDisplay();
	}

}
