package com.ShortHandSetterAndConstructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass008 
{
	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("Setter&ConstructorShortHand.xml");
		
		Test1 test2 = (Test1)context.getBean("test1");
		
		System.out.println(test2);
	}
}
