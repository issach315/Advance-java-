package com.ShortHandSetterAndConstructor;

public class Car {
	
	private String carModel;
	
	private String carColor;

	
	public String getCarModel() {
		return carModel;
	}


	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}


	public String getCarColor() {
		return carColor;
	}


	public void setCarColor(String carColor) {
		this.carColor = carColor;
	}


	@Override
	public String toString() {
		return "Car [carModel=" + carModel + ", carColor=" + carColor + "]";
	}

	

}
