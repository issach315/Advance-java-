package com.ShortHandSetterAndConstructor;

public class Test1
{
	private String carBrand;
	
	private Car car;

	
	public Test1(String carBrand, Car car) {
		
		this.carBrand = carBrand;
		this.car = car;
	}

	@Override
	public String toString() {
		return "Test1 [carBrand=" + carBrand + ", car=" + car + "]";
	}
	
	

}
