package com.DpendencyOn;

public class A 
{
	A()
	{
		System.out.println("A object");
	}

}
	