package com.DpendencyOn;

public class C
{
	C()
	{
		System.out.println("C object");
	}

}
