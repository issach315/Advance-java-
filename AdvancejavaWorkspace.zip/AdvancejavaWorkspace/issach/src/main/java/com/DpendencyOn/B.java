package com.DpendencyOn;

public class B 
{
	B()
	{
		System.out.println("B object");
	}

}
