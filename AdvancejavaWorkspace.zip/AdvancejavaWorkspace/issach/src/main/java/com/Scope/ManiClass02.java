package com.Scope;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class ManiClass02 
{
	public static void main(String[] args)
	{
	/*  Resource resource = new ClassPathResource("Scope.xml");
		BeanFactory context = new XmlBeanFactory(resource);  */
		
		ApplicationContext context = new ClassPathXmlApplicationContext("Scope.xml");
		
		
		Test1 test = (Test1)context.getBean("t1");
		Test1 test2 = (Test1)context.getBean("t1");
		Test1 test3 = (Test1)context.getBean("t1");
	}

}
