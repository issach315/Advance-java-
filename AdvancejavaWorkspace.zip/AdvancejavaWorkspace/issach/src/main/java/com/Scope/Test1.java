package com.Scope;

public class Test1 
{
	private Test1()
	{
		System.out.println("Constructor......");
	}

}
