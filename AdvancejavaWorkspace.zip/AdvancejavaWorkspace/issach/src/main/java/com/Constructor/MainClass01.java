package com.Constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass01
{
	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("car.xml");
		Car car1 = (Car)context.getBean("car1");
		
		System.out.println(car1.toString());
	}

}
