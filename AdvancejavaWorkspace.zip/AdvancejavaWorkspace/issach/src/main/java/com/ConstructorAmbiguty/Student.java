package com.ConstructorAmbiguty;

public class Student
{
	private String stdName;
	private int stdRollNo;
	private boolean stdResult;
	
	
	public Student(String stdName, int stdRollNo, boolean stdResult) 
	{
		
		this.stdName = stdName;
		this.stdRollNo = stdRollNo;
		this.stdResult = stdResult;
	}


	@Override
	public String toString() {
		return "Student [stdName=" + stdName + ", stdRollNo=" + stdRollNo + ", stdResult=" + stdResult + "]";
	}
	
	

}
