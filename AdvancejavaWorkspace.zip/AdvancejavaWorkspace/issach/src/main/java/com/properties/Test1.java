package com.properties;

import java.util.Properties;

public class Test1 
{
	private Properties Drivers;


	public void setDrivers(Properties drivers) {
		Drivers = drivers;
	}


	@Override
	public String toString() {
		return "Test1 [Drivers=" + Drivers + "]";
	}
	
	
	

}
