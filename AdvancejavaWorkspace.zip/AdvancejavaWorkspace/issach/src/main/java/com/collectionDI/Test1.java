package com.collectionDI;

import java.util.*;

public class Test1
{
	private List fruits;
	
	private Set cricketers;
	
	private Map cc;

	public List getFruits() {
		return fruits;
	}

	public void setFruits(List fruits) {
		this.fruits = fruits;
	}

	public Set getCricketers() {
		return cricketers;
	}

	public void setCricketers(Set cricketers) {
		this.cricketers = cricketers;
	}

	public Map getCc() {
		return cc;
	}

	public void setCc(Map cc) {
		this.cc = cc;
	}

	@Override
	public String toString() {
		return "Test1 [fruits=" + fruits + ", cricketers=" + cricketers + ", cc=" + cc + "]";
	}
	
	/*public void printData()
	{
		System.out.println("Fruits..............");
		
		for(Object fruit:fruits)
		{
			System.out.println(fruit);
		}
		
		System.out.println("Cricketers..............");
		
		for(Object cricketer:cricketers)
		{
			System.out.println(cricketers);
		}
		
		System.out.println("countery and capitals");
		
		Set keys =cc.keySet();
		
		for(Object key:keys )
		{
			System.out.println("countery = "+key+" : capital"+cc.get(key));
		}
	}*/
	
	
	
	

}
