package com.StaticDI;

public class Student 
{
	private static  String stdName;
	
	public static void setStdName(String stdName)
	{
		Student.stdName=stdName;
		
	}
	
	public  static void printData()
	{
		System.out.println(" Student Name : "+stdName);
	}

}
