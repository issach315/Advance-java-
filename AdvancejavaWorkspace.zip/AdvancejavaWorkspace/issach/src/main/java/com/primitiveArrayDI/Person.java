package com.primitiveArrayDI;

import java.util.Arrays;

public class Person
{
	private String stdName[];

	public String[] getStdName() {
		return stdName;
	}

	public void setStdName(String[] stdName) {
		this.stdName = stdName;
	}

	@Override
	public String toString() {
		return "Person [stdName=" + Arrays.toString(stdName) + "]";
	}
	
	
	
	

}
