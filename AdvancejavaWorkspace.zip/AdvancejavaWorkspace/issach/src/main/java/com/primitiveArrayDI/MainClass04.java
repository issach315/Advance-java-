package com.primitiveArrayDI;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass04 
{
	public static void main(String[] args) 
	{
		// loading the xml file into the IOC container 
		ApplicationContext context = new ClassPathXmlApplicationContext("primitiveArraysDI.xml");
		
		Person p1 = (Person)context.getBean("p2");
		
		System.out.println(p1.toString());
		
		
	}

}
