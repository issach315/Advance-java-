package Simple;

public class Main010203

{
	public static void main(String[] args)
	{
		
		int num =987654;
		
		int num1 =0;
		
		while(num !=0)
		{
			int lastdigit =0;
			
			lastdigit=num%10;
			
			num1= num1*10+lastdigit;
			
			num=num/10;
		}
		
		System.out.println(num1);
		
		
	}
	
	

}
